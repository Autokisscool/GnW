Scripts in here were just developed to indirectly aid in reverse engineering.
These scripts won't be polished or well documented.
